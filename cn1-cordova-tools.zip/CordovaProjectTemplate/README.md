# Cordova Project Template

This project is designed to serve as a "hello world" template for building Cordova applications in Codename One.

## Modifications from Standard Hello World Template:

* Includes a custom ANT task for generating the cordova_plugins.js file.
* Includes the CN1JSON.cn1lib and cordova.cn1lib libraries.
* build.xml file has been modified to copy resources from libraries into the build/classes directory after compile.
